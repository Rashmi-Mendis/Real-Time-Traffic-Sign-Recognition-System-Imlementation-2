package com.example.auditory;

import java.util.ArrayList;
import java.util.List;

public class TrafficSignPrioritizer {

    // Define priority categories
    private static final List<String> WARNING_SIGNS;

    static {
        WARNING_SIGNS = new ArrayList<> ();
        WARNING_SIGNS.add ("CHILDREN CROSSING AHEAD");
        WARNING_SIGNS.add ("PEDESTRIAN CROSSING AHEAD");
        WARNING_SIGNS.add ("ROAD WORK AHEAD");
        WARNING_SIGNS.add ("LEVEL CROSSING WITH GATES AHEAD");
        WARNING_SIGNS.add ("LEFT BEND AHEAD");
        WARNING_SIGNS.add ("RIGHT BEND AHEAD");
        WARNING_SIGNS.add ("DOUBLE BEND TO LEFT AHEAD");
        WARNING_SIGNS.add ("DOUBLE BEND TO RIGHT AHEAD");
        WARNING_SIGNS.add ("ROAD NARROWS AHEAD");
        WARNING_SIGNS.add ("ROAD NARROWS ON THE LEFT SIDE AHEAD");
        WARNING_SIGNS.add ("ROAD NARROWS ON THE RIGHT SIDE AHEAD");
    }

    private static final List<String> RESTRICTIVE_SIGNS;

    static {
        RESTRICTIVE_SIGNS = new ArrayList<> ();
        RESTRICTIVE_SIGNS.add ("SPEED LIMIT 60 KM/H");
        RESTRICTIVE_SIGNS.add ("SPEED LIMIT 70 KM/H");
        RESTRICTIVE_SIGNS.add ("SPEED LIMIT 80 KM/H");
        RESTRICTIVE_SIGNS.add ("SPEED LIMIT 100 KM/H");
    }

    private static final List<String> PROHIBITORY_SIGNS;

    static {
        PROHIBITORY_SIGNS = new ArrayList<> ();
        PROHIBITORY_SIGNS.add ("NO ENTRY");
        PROHIBITORY_SIGNS.add ("NO LEFT TURN");
        PROHIBITORY_SIGNS.add ("NO RIGHT TURN");
        PROHIBITORY_SIGNS.add ("NO U-TURN");
    }

    public void prioritizeAudioTexts(List<String> audioTexts) {
        List<String> prioritizedList = new ArrayList<>();

        // Add warning signs first
        for (String sign : WARNING_SIGNS) {
            if (audioTexts.contains(sign)) {
                prioritizedList.add(sign);
            }
        }

        // Add restrictive signs second
        for (String sign : RESTRICTIVE_SIGNS) {
            if (audioTexts.contains(sign)) {
                prioritizedList.add(sign);
            }
        }

        // Add prohibitory signs last
        for (String sign : PROHIBITORY_SIGNS) {
            if (audioTexts.contains(sign)) {
                prioritizedList.add(sign);
            }
        }

        // Clear the original list and add prioritized signs back
        //audioTexts.clear();
        audioTexts.addAll(prioritizedList);
    }
}


////import java.util.ArrayList;
////import java.util.Collections;
////import java.util.Comparator;
////import java.util.HashMap;
////import java.util.List;
////import java.util.Map;
////
////public class TrafficSignPrioritizer {
////
////    // Define a map to hold sign names and their corresponding priority scores
////    private final Map<String, Double> priorityMap = new HashMap<>();
////
////    public TrafficSignPrioritizer() {
////        // Assign priority scores for warning signs
////        priorityMap.put("LEVEL CROSSING WITH GATES AHEAD", 1.1);
////        priorityMap.put("PEDESTRIAN CROSSING AHEAD", 1.2);
////        priorityMap.put("CHILDREN CROSSING AHEAD", 1.3);
////        priorityMap.put("ROAD WORK AHEAD", 1.4);
////        priorityMap.put("ROAD NARROWS ON THE LEFT SIDE AHEAD", 1.5);
////        priorityMap.put("ROAD NARROWS ON THE RIGHT SIDE AHEAD", 1.6);
////        priorityMap.put("RIGHT BEND AHEAD", 1.7);
////        priorityMap.put("LEFT BEND AHEAD", 1.8);
////        priorityMap.put("DOUBLE BEND TO LEFT AHEAD", 1.9);
////        priorityMap.put("DOUBLE BEND TO RIGHT AHEAD", 1.9);
////
////        // Assign priority scores for restrictive signs
////        priorityMap.put("SPEED LIMIT 60 KM/H", 2.1);
////        priorityMap.put("SPEED LIMIT 70 KM/H", 2.2);
////        priorityMap.put("SPEED LIMIT 80 KM/H", 2.3);
////        priorityMap.put("SPEED LIMIT 100 KM/H", 2.4);
////
////        // Assign priority scores for prohibitory signs
////        priorityMap.put("NO ENTRY", 3.1);
////        priorityMap.put("NO LEFT TURN", 3.2);
////        priorityMap.put("NO RIGHT TURN", 3.3);
////        priorityMap.put("NO U-TURN", 3.4);
////    }
////
////    public void prioritizeAudioTexts(List<String> audioTexts) {
////        List<SignWithPriority> prioritizedList = new ArrayList<>();
////
////
////
////        // Assign priority scores to detected signs
////        for (String sign : audioTexts) {
////            if (priorityMap.containsKey(sign)) {
////                double priorityScore = priorityMap.get(sign);
////                prioritizedList.add(new SignWithPriority(sign, priorityScore));
////            }
////        }
////
////        // Sort the list by priority score
////        Collections.sort(prioritizedList, Comparator.comparingDouble(SignWithPriority::getPriorityScore));
////
////        // Clear the original list and add prioritized signs back
////        //audioTexts.clear();
////        for (SignWithPriority signWithPriority : prioritizedList) {
////            audioTexts.add(signWithPriority.getSignName());
////        }
////    }
////
////    // Inner class to hold sign and its priority
////    private static class SignWithPriority {
////        private final String signName;
////        private final double priorityScore;
////
////        public SignWithPriority(String signName, double priorityScore) {
////            this.signName = signName;
////            this.priorityScore = priorityScore;
////        }
////
////        public String getSignName() {
////            return signName;
////        }
////
////        public double getPriorityScore() {
////            return priorityScore;
////        }
////    }
////}


//package com.example.auditory;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//public class TrafficSignPrioritizer {
//
//    // Define signs with their respective priority scores
//    private final Map<String, Double> signPriority = new HashMap<String, Double> () {{
//
//        // Warning signs - higher urgency
//        put("LEVEL CROSSING WITH GATES AHEAD", 1.1);
//        put("PEDESTRIAN CROSSING AHEAD", 1.2);
//        put("CHILDREN CROSSING AHEAD", 1.3);
//        put("ROAD WORK AHEAD", 1.4);
//        put("ROAD NARROWS ON THE LEFT SIDE AHEAD", 1.5);
//        put("ROAD NARROWS ON THE RIGHT SIDE AHEAD", 1.6);
//        put("LEFT BEND AHEAD", 1.7);
//        put("RIGHT BEND AHEAD", 1.8);
//        put("DOUBLE BEND TO LEFT AHEAD", 1.9);
//        put("DOUBLE BEND TO RIGHT AHEAD", 1.9);
//
//        // Restrictive signs
//        put("SPEED LIMIT 60 KM/H", 2.1);
//        put("SPEED LIMIT 70 KM/H", 2.2);
//        put("SPEED LIMIT 80 KM/H", 2.3);
//        put("SPEED LIMIT 100 KM/H", 2.4);
//
//        // Prohibitory signs
//        put("NO ENTRY", 3.1);
//        put("NO LEFT TURN", 3.2);
//        put("NO RIGHT TURN", 3.3);
//        put("NO U-TURN", 3.4);
//    }};
//
//    public void prioritizeAudioTexts(List<String> audioTexts) {
//        // Sort the audioTexts based on their priority scores
//        audioTexts.sort((sign1, sign2) -> {
//            double priority1 = signPriority.getOrDefault(sign1, Double.MAX_VALUE); // Default to a high value if not found
//            double priority2 = signPriority.getOrDefault(sign2, Double.MAX_VALUE);
//            return Double.compare(priority1, priority2);
//        });
//    }
//}
//package com.example.auditory;
//
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//public class TrafficSignPrioritizer {
//
//    // Define signs with their respective priority scores
//    private final Map<String, Double> signPriority = new HashMap<>() {{
//        // Warning signs (Highest Priority)
//        put("LEVEL CROSSING WITH GATES AHEAD", 1.1);
//        put("PEDESTRIAN CROSSING AHEAD", 1.2);
//        put("CHILDREN CROSSING AHEAD", 1.3);
//        put("ROAD WORK AHEAD", 1.4);
//        put("ROAD NARROWS ON THE LEFT SIDE AHEAD", 1.5);
//        put("ROAD NARROWS ON THE RIGHT SIDE AHEAD", 1.6);
//        put("LEFT BEND AHEAD", 1.7);
//        put("RIGHT BEND AHEAD", 1.8);
//        put("DOUBLE BEND TO LEFT AHEAD", 1.9);
//        put("DOUBLE BEND TO RIGHT AHEAD", 1.9);
//
//        // Restrictive signs (Medium Priority)
//        put("SPEED LIMIT 60 KM/H", 2.1);
//        put("SPEED LIMIT 70 KM/H", 2.2);
//        put("SPEED LIMIT 80 KM/H", 2.3);
//        put("SPEED LIMIT 100 KM/H", 2.4);
//
//        // Prohibitory signs (Lowest Priority)
//        put("NO ENTRY", 3.1);
//        put("NO LEFT TURN", 3.2);
//        put("NO RIGHT TURN", 3.3);
//        put("NO U-TURN", 3.4);
//    }};
//
//    public void prioritizeAudioTexts(List<String> audioTexts) {
//        // Sort the audioTexts based on their priority scores
//        audioTexts.sort((sign1, sign2) -> {
//            double priority1 = signPriority.getOrDefault(sign1, Double.MAX_VALUE); // Default to a high value if not found
//            double priority2 = signPriority.getOrDefault(sign2, Double.MAX_VALUE);
//
//            return Double.compare(priority1, priority2);
//        });
//    }
//}
