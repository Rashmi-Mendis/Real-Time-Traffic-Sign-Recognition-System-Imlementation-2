package com.example.auditory;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;




//import org.tensorflow.lite.Interpreter;



public class MainActivity extends AppCompatActivity {

    DatabaseHelper mySQLConnection;
    private Connection con;
    private ImageView imageView, imageView1, signView;
    private TextView labelView;
    private Handler handler = new Handler ();

    private List<String> audioTexts;
    String str;
    private static final String TAG = "MainActivity";
    private Runnable runnable;

    private boolean isMuted = false;
    private TextView dateTimeView;

    private ImageButton muteUnmuteButton;
    private ImageButton endSessionButton;

    private AudioManager audioManager;

    private TextToSpeech textToSpeech;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);

        textToSpeech = new TextToSpeech (this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = textToSpeech.setLanguage (Locale.US);
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e (TAG, "TTS language not supported");
                }
            } else {
                Log.e (TAG, "TTS initialization failed");
            }
        });


        imageView = findViewById (R.id.imgGlide);
        imageView1 = findViewById (R.id.imgGlide1);
        labelView = findViewById (R.id.label_view);
        signView = findViewById (R.id.sign_view);
        dateTimeView = findViewById (R.id.date_time_view);
        muteUnmuteButton = findViewById (R.id.mute_unmute);
        endSessionButton = findViewById (R.id.end_session_button);
        audioManager = (AudioManager) getSystemService (AUDIO_SERVICE);


        // Initialize database connection
        mySQLConnection = new DatabaseHelper ();
        audioTexts = new ArrayList<> ();

        connect ();
        imgGlide ();
        updateLabelAndSign ();
        fetchAudioTexts ();
        // Play audio after fetching
      //  runOnUiThread (this::playTextAudio);

        // Initialize handler for periodic updates
        handler = new Handler ();
        runnable = new Runnable () {
            @Override
            public void run() {
                updateDateTime ();
                handler.postDelayed (this, 2000);
            }
        };
        handler.post (runnable);

        // Setup mute un-mute button click listener
        muteUnmuteButton.setOnClickListener (v -> toggleMute ());

        // Setup end session button click listener
        endSessionButton.setOnClickListener (v -> showEndSessionDialog ());

        audioManager.setStreamVolume (AudioManager.STREAM_MUSIC,
                audioManager.getStreamMaxVolume (AudioManager.STREAM_MUSIC), 0);
    }

    private void showEndSessionDialog() {
        new AlertDialog.Builder (this)
                .setTitle ("End Session")
                .setMessage ("Are you sure you want to end the session?")
                .setPositiveButton ("OK", (dialog, which) -> {
                    finish (); // Close the activity and the app
                })
                .setNegativeButton ("Cancel", null)
                .show ();
    }

    private void updateDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss", Locale.getDefault ());
        String currentDateAndTime = sdf.format (new Date ());
        dateTimeView.setText (currentDateAndTime);
    }

    private void toggleMute() {
        if (isMuted) {
            audioManager.setStreamMute (AudioManager.STREAM_MUSIC, false);
            muteUnmuteButton.setImageResource (R.drawable.volume);
            Toast.makeText (MainActivity.this, "Sound is un-muted", Toast.LENGTH_SHORT).show ();
        } else {
            audioManager.setStreamMute (AudioManager.STREAM_MUSIC, true);
            muteUnmuteButton.setImageResource (R.drawable.volume_off);
            Toast.makeText (MainActivity.this, "Sound is muted", Toast.LENGTH_SHORT).show ();
        }
        isMuted = !isMuted;
    }

    public void imgGlide() {
        ExecutorService executorService = Executors.newSingleThreadExecutor ();
        executorService.execute (() -> {
            PreparedStatement stmt = null;
            ResultSet rs = null;
            List<String> urlList = new ArrayList<> ();
            try {
                con = mySQLConnection.CONN ();
                if (con == null) {
                    Log.e (TAG, "Database connection failed");
                    return;
                }
                String query = "SELECT CAPTURED_FRAME FROM record_video WHERE VIDEO_ID = 'v003'";
                stmt = con.prepareStatement (query);
                rs = stmt.executeQuery ();

                while (rs.next ()) {
                    urlList.add (rs.getString ("CAPTURED_FRAME").trim ());
                }
            } catch (SQLException e) {
                Log.e (TAG, "SQL Exception: ", e);
            } finally {
                try {
                    if (rs != null) rs.close ();
                    if (stmt != null) stmt.close ();
                    if (con != null) con.close ();
                } catch (SQLException e) {
                    Log.e (TAG, "Error closing resources: ", e);
                }
            }

            runOnUiThread (() -> {
                if (urlList.isEmpty ()) {
                    Toast.makeText (MainActivity.this, "No URLs found", Toast.LENGTH_SHORT).show ();
                } else {
                    displayImages (urlList);
                }
            });
        });
    }

    private void displayImages(List<String> urlList) {
        final Handler handler = new Handler ();
        final int[] index = {0};
        final Animation fadeIn = AnimationUtils.loadAnimation (this, R.anim.fade_in);

        Runnable runnable = new Runnable () {
            @Override
            public void run() {
                if (!urlList.isEmpty ()) {
                    String url = urlList.get (index[0]);
                    Log.d (TAG, "Image URL/Path: " + url);

                    if (url.startsWith ("http") || url.startsWith ("https")) {
                        if (index[0] % 2 == 0) {
                            imageView.startAnimation (fadeIn);
                            Glide.with (MainActivity.this).load (url).into (imageView);
                        } else {
                            imageView1.startAnimation (fadeIn);
                            Glide.with (MainActivity.this).load (url).into (imageView1);
                        }
                    } else {
                        Toast.makeText (MainActivity.this, "Invalid URL or Path: " + url, Toast.LENGTH_SHORT).show ();
                    }
                    index[0]++;
                    if (index[0] >= urlList.size ()) {
                        index[0] = 0; // Reset index to loop the images
                    }
                    handler.postDelayed (this, 2000); // Change image every second
                }
            }
        };
        handler.post (runnable);
    }

    public void connect() {
        ExecutorService executorService = Executors.newSingleThreadExecutor ();
        executorService.execute (() -> {
            try {
                con = mySQLConnection.CONN ();
                if (con == null) {
                    str = "Error in connection with MySQL Server";
                } else {
                    str = "Connected with MySQL server";
                }
            } catch (Exception e) {
                Log.e (TAG, "Connection Exception: ", e);
                str = "Exception in connection";
            } finally {
                runOnUiThread (() -> Toast.makeText (MainActivity.this, str, Toast.LENGTH_SHORT).show ());
            }
        });
    }

    private void updateLabelAndSign() {
        ExecutorService executorService = Executors.newSingleThreadExecutor ();
        executorService.execute (() -> {
            PreparedStatement stmt = null;
            ResultSet rs = null;
            try {
                con = mySQLConnection.CONN ();
                if (con == null) {
                    Log.e (TAG, "Database connection failed");
                    return;
                }
                String query = "SELECT SIGN_NAME, SEGMENTED_SIGN FROM record_video WHERE VIDEO_ID = 'v003'";
                stmt = con.prepareStatement (query);
                rs = stmt.executeQuery ();

                List<String> labels = new ArrayList<> ();
                List<String> signUrls = new ArrayList<> ();

                while (rs.next ()) {
                    String signName = rs.getString ("SIGN_NAME");
                    String segmentedSign = rs.getString ("SEGMENTED_SIGN");

                    labels.add (signName != null ? signName : "Unknown Sign");
                    signUrls.add (segmentedSign != null ? segmentedSign : "No URL");
                }

                runOnUiThread (() -> {
                    updateLabelView (labels);
                    updateSignView (signUrls);
                });
            } catch (SQLException e) {
                Log.e (TAG, "SQL Exception: ", e);
            } finally {
                try {
                    if (rs != null) rs.close ();
                    if (stmt != null) stmt.close ();
                    if (con != null) con.close ();
                } catch (SQLException e) {
                    Log.e (TAG, "Error closing resources: ", e);
                }
            }
        });
    }

    private void updateLabelView(List<String> labels) {
        final Handler handler = new Handler ();
        final int[] index = {0};

        Runnable runnable = new Runnable () {
            @Override
            public void run() {
                if (!labels.isEmpty ()) {
                    String label = labels.get (index[0]);
                    labelView.setText (label);

                    // Play the appropriate audio for the current signName
                    if (isWarningSign(label)) {
                        higherPriorityAlert(); // Play urgent alert for warning signs
                        playTextAudio(label);
                    } else if (isRestrictiveSign(label)) {
                        mediumPriorityAlert();
                        playTextAudio(label); // Play text-to-speech for restrictive signs
                    } else if (isProhibitorySign(label)) {
                        lowerPriorityAlert ();
                        playTextAudio(label); // Play text-to-speech for prohibitory signs
                    } else {
                       // playTextAudio(label);
                       // showInformationalMessage(label); // Show informational message
                    }


                    index[0]++;
                    if (index[0] >= labels.size ()) {
                        index[0] = 0; // Reset index to loop the labels
                    }
                    handler.postDelayed (this, 2000);
                }
            }
        };
        handler.post (runnable);
    }

    private void updateSignView(List<String> signUrls) {
        final Handler handler = new Handler ();
        final int[] index = {0};
        final Animation fadeIn = AnimationUtils.loadAnimation (this, R.anim.fade_in);

        Runnable runnable = new Runnable () {
            @Override
            public void run() {
                if (!signUrls.isEmpty ()) {
                    String signUrl = signUrls.get (index[0]);
                    signView.startAnimation (fadeIn);
                    Glide.with (MainActivity.this).load (signUrl).into (signView);

                    index[0]++;
                    if (index[0] >= signUrls.size ()) {
                        index[0] = 0; // Reset index to loop the signs
                    }
                    handler.postDelayed (this, 2000);
                }
            }
        };
        handler.post (runnable);
    }

    // Fetch Audio Texts from DB
    private void fetchAudioTexts() {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            PreparedStatement stmt = null;
            ResultSet rs = null;
            try {
                con = mySQLConnection.CONN();
                if (con == null) {
                    Log.e(TAG, "Database connection failed");
                    return;
                }

                String query = "SELECT SIGN_NAME FROM record_video WHERE VIDEO_ID = 'v003'";
                stmt = con.prepareStatement(query);
                rs = stmt.executeQuery();

                List<String> signsToPlay = new ArrayList<>();
                while (rs.next()) {
                    String signName = rs.getString("SIGN_NAME");
                    if (signName != null) {
                        signsToPlay.add(signName);
                    } else {
                        Log.e(TAG, "SIGN_NAME is null for VIDEO_ID: 'v003'");
                    }
                }

            } catch (SQLException e) {
                Log.e(TAG, "SQL Exception: ", e);
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (SQLException e) {
                    Log.e(TAG, "Error closing resources: ", e);
                }
            }
        });
    }

    // Helper to play text-to-speech for a specific signName
    private void playTextAudio(String text) {
        if (text == null || text.isEmpty()) {
            Log.e(TAG, "No text provided for audio playback");
            return;
        }

        Log.d(TAG, "Playing audio for text: " + text);
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    private void higherPriorityAlert() {
        MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.high_priority); // Ensure the file exists
        if (mediaPlayer != null) {
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(mp -> {
                mp.release();
                Log.d(TAG, "Urgent alert playback completed.");
            });
        } else {
            Log.e(TAG, "MediaPlayer failed to create for urgent alert.");
        }
    }

    private void mediumPriorityAlert() {
        MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.medium_priority); // Ensure the file exists
        if (mediaPlayer != null) {
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(mp -> {
                mp.release();
                Log.d(TAG, "Urgent alert playback completed.");
            });
        } else {
            Log.e(TAG, "MediaPlayer failed to create for urgent alert.");
        }
    }

    private void lowerPriorityAlert() {
        MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.low_priority); // Ensure the file exists
        if (mediaPlayer != null) {
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(mp -> {
                mp.release();
                Log.d(TAG, "Urgent alert playback completed.");
            });
        } else {
            Log.e(TAG, "MediaPlayer failed to create for urgent alert.");
        }
    }


    private boolean isWarningSign(String sign) {
        if (sign == null) {
            Log.e(TAG, "Warning sign is null");
            return false;
        }
        String upperSign = sign.toUpperCase();
        boolean isWarning = upperSign.contains("LEFT BEND AHEAD") ||
                upperSign.contains("RIGHT BEND AHEAD") ||
                upperSign.contains("DOUBLE BEND TO LEFT AHEAD") ||
                upperSign.contains("DOUBLE BEND TO RIGHT AHEAD") ||
                upperSign.contains("ROAD WORK AHEAD") ||
                upperSign.contains("ROAD NARROWS AHEAD") ||
                upperSign.contains("ROAD NARROWS ON THE LEFT SIDE AHEAD") ||
                upperSign.contains("ROAD NARROWS ON THE RIGHT SIDE AHEAD") ||
                upperSign.contains("PEDESTRIAN CROSSING AHEAD") ||
                upperSign.contains("CHILDREN CROSSING AHEAD") ||
                upperSign.contains("LEVEL CROSSING WITH GATES AHEAD");

        Log.d(TAG, "Is warning sign: " + isWarning + " for sign: " + sign);
        return isWarning;
    }

    private boolean isRestrictiveSign(String sign) {
        if (sign == null) {
            Log.e(TAG, "Restrictive sign is null");
            return false;
        }
        String upperSign = sign.toUpperCase();
        boolean isRestrictive = upperSign.contains("SPEED LIMIT AT 60KMPH") ||
                upperSign.contains("SPEED LIMIT AT 70KMPH") ||
                upperSign.contains("SPEED LIMIT AT 80KMPH") ||
                upperSign.contains("SPEED LIMIT AT 100KMPH");

        Log.d(TAG, "Is restrictive sign: " + isRestrictive + " for sign: " + sign);
        return isRestrictive;
    }

    private boolean isProhibitorySign(String sign) {
        if (sign == null) {
            Log.e(TAG, "Prohibitory sign is null");
            return false;
        }
        String upperSign = sign.toUpperCase();
        boolean isProhibit = upperSign.contains("NO ENTRY") ||
                upperSign.contains("NO LEFT TURN") ||
                upperSign.contains("NO RIGHT TURN") ||
                upperSign.contains("NO U-TURN");

        Log.d(TAG, "Is prohibitory sign: " + isProhibit + " for sign: " + sign);
        return isProhibit;
    }

//    private void showInformationalMessage(String message) {
//        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
//    }


    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop ();
            textToSpeech.shutdown ();
        }
        super.onDestroy ();
    }
}